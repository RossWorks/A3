printf("Airplane Aerodynamic Analysis\n");
printf("Author: Ross Works\n\nVersion 1.0\n");
for i=1:20
printf("-");
endfor
printf("\n\n");